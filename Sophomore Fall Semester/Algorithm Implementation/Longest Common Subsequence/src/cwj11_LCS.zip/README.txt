Connor Johnson
Longest Common Subsequence

Files:	
TestLCS.java
LCS.java

Compile TestLCS.java with Java 1.5 or later

Description:
This program finds the longest common subsequence between two strings. It does this by using a memoized recursive algorithm. I was able
to run my program in reasonable time up to 1500 characters until I started top get stack overflow errors.

Problems:
No known problems
